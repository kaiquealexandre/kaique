print("Programa para ordenar números.")

numero1 = int(input("Digite o primeiro número:"))
numero2 = int(input("Digite o primeiro número:"))
numero3 = int(input("Digite o primeiro número:"))

lista = [numero1, numero2, numero3]

numerosOrdenados = sorted(lista)

print(numerosOrdenados)