print("Programa que verifica se é par ou ímpar")

valor = int(input("Digite um número:"))
if(valor%2 == 0):
    print("Este número é par.")
else:
    print("Este número é ímpar.")