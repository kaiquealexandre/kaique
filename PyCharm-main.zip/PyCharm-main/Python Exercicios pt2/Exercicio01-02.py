print("Programa para calcular a área de um triângulo.")

base = float(input("Entre com a base do triângulo:"))
altura = float(input("Entre com a altura do triângulo:"))

area = base * altura / 2
print("A área do triângulo é:", area)