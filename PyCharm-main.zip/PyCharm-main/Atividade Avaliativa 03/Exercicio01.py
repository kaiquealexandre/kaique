print("Programa que transforma fahrenheit para celsius.")

f = float(input("Digite uma temperatura em fahrenheit:"))

c = 5/9 * (f-32)

print("A temperatura em Celsius é: {}".format(c))
