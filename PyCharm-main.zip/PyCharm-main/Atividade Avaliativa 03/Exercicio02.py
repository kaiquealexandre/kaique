print("Programa que calcula o valor da hora trabalhada.")

salario_base = float(input("Digite o salário base por hora: "))
horas_extras = float(input("Digite o total de horas extras trabalhadas na semana: "))

valor_hora_normal = salario_base * 1.5           #1,5 = 50%
valor_hora_total = (salario_base + valor_hora_normal) / 40

print("O valor da hora trabalhada, considerando as horas extras, é:", valor_hora_total)
