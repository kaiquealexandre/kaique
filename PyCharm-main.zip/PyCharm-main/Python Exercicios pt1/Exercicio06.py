print("Programa que mostra os multiplos de 3 de 1 a 100.")
contador = 1
while(contador <= 100):
    if(contador%3 == 0):
       print(contador, "é multiplo de 3.")
    contador = contador + 1
print("Fim do programa!")