numero01 = int(input("Digite o primeiro número."))
numero02 = int(input("Digite o segundo número."))

if(numero01 >= numero02):
    print("O primeiro número {} é maior{}." .format( numero01, numero02))
else:
    print("O segundo número {} é maior {}." .format( numero02, numero01))

