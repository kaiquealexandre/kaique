print("Programa que verifica nome e idade.")

nome = input("Entre com seu nome:")
idade = int(input("Digite sua idade:"))

print("Seu nome é:", nome)
print("Sua idade é:", idade)
