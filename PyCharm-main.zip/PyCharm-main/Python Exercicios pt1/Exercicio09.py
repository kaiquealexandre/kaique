def main():
    print("Números pares de 0 a 30:")
    for i in range(0, 31, 2):
        print(i)

if __name__ == "__main__":
    main()