print("Programa que verifica se você pode votar ou não.")

idade = int(input("Digite sua idade:"))

while(idade >= 16):
        print("Você pode votar!!")
if(idade <= 16):
        print("Você não pode votar!!")
